# NSE QUOTATION – React Native Source Code
## N Square Energies · Solar Quotation App

---

## 📁 PROJECT STRUCTURE

```
NSE_RN_Source/
├── App.tsx                    ← Root app + navigation
├── package.json               ← Dependencies
├── app.json                   ← Expo config
├── src/
│   ├── screens/
│   │   ├── SplashScreen.tsx   ← Splash with logo
│   │   ├── HomeScreen.tsx     ← Main menu
│   │   ├── NewQuoteScreen.tsx ← Quote form
│   │   ├── SavedScreen.tsx    ← Saved quotations list
│   │   ├── PDFScreen.tsx      ← PDF preview & share
│   │   └── SettingsScreen.tsx ← Company settings
│   ├── components/
│   │   ├── FormField.tsx      ← Reusable input field
│   │   ├── ToggleRow.tsx      ← Toggle with label
│   │   ├── QuoteCard.tsx      ← Saved quote list card
│   │   └── GSTBox.tsx         ← GST calculation display
│   ├── utils/
│   │   ├── db.ts              ← SQLite/AsyncStorage CRUD
│   │   ├── gst.ts             ← GST calculation logic
│   │   ├── pdfBuilder.ts      ← HTML→PDF generator
│   │   ├── quoteNum.ts        ← Auto quote numbering
│   │   └── words.ts           ← Number to words (INR)
│   └── assets/
│       ├── logo.png           ← N Square Energies logo
│       └── icon.png           ← App icon
├── android/                   ← Android native files
└── ios/                       ← iOS native files (optional)
```

---

## 🚀 HOW TO COMPILE APK

### Option 1 – Expo (Easiest)
```bash
# Install Expo CLI
npm install -g expo-cli eas-cli

# Install dependencies
cd NSE_RN_Source
npm install

# Login to Expo
eas login

# Build APK for Android
eas build -p android --profile preview

# Download APK from the Expo dashboard link
```

### Option 2 – Android Studio
```bash
# Install dependencies
npm install

# Generate Android project
npx expo prebuild --platform android

# Open in Android Studio
# File → Open → select /android folder
# Build → Generate Signed Bundle/APK
```

### Option 3 – Expo Go (Test immediately)
```bash
npm install
npx expo start
# Scan QR code with Expo Go app on your phone
```

---

## 📦 package.json
```json
{
  "name": "nse-quotation",
  "version": "1.0.0",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "build": "eas build -p android"
  },
  "dependencies": {
    "expo": "~50.0.0",
    "expo-status-bar": "~1.11.1",
    "expo-print": "~12.8.0",
    "expo-sharing": "~11.10.0",
    "expo-file-system": "~16.0.6",
    "expo-sqlite": "~13.4.0",
    "@react-navigation/native": "^6.1.9",
    "@react-navigation/stack": "^6.3.20",
    "react-native-paper": "^5.11.7",
    "react-native-vector-icons": "^10.0.3",
    "@react-native-async-storage/async-storage": "1.21.0",
    "react-native-share": "^10.0.2",
    "react-native": "0.73.0",
    "react": "18.2.0"
  },
  "devDependencies": {
    "@babel/core": "^7.20.0",
    "typescript": "^5.1.0"
  }
}
```

---

## 📱 app.json (Expo Config)
```json
{
  "expo": {
    "name": "NSE Quotation",
    "slug": "nse-quotation",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./src/assets/icon.png",
    "splash": {
      "image": "./src/assets/logo.png",
      "resizeMode": "contain",
      "backgroundColor": "#060f06"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./src/assets/icon.png",
        "backgroundColor": "#0a2e0a"
      },
      "package": "com.nsquareenergies.quotation",
      "versionCode": 1,
      "permissions": ["WRITE_EXTERNAL_STORAGE","READ_EXTERNAL_STORAGE"]
    },
    "plugins": [
      "expo-sqlite",
      "expo-print",
      "expo-sharing"
    ]
  }
}
```

---

## 🗄️ src/utils/db.ts
```typescript
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Quote {
  id: string;
  quoteNum: string;
  date: string;
  name: string;
  phone: string;
  address: string;
  sysType: 'On-Grid' | 'Off-Grid' | 'Hybrid';
  kw: string;
  panelBrand: string;
  panelSpec: string;
  panelQty: string;
  invBrand: string;
  invModel: string;
  structure: string;
  battery: boolean;
  battBrand: string;
  battCap: string;
  baseCost: number;
  g5: number;
  g18: number;
  gstTotal: number;
  grandTotal: number;
  netMeter: boolean;
  civil: boolean;
  monitoring: boolean;
  wPanel: string;
  wInv: string;
  wStruct: string;
  notes: string;
  savedAt: string;
}

export interface Settings {
  coName: string;
  coAddr: string;
  coPhone: string;
  coEmail: string;
  gst5: number;
  gst18: number;
  validity: number;
  sigName: string;
  sigDesig: string;
  terms: string;
}

const QUOTES_KEY = 'nse_quotes';
const SETTINGS_KEY = 'nse_settings';

export const getQuotes = async (): Promise<Quote[]> => {
  const raw = await AsyncStorage.getItem(QUOTES_KEY);
  return raw ? JSON.parse(raw) : [];
};

export const saveQuotes = async (quotes: Quote[]) => {
  await AsyncStorage.setItem(QUOTES_KEY, JSON.stringify(quotes));
};

export const saveQuote = async (quote: Quote) => {
  const quotes = await getQuotes();
  const idx = quotes.findIndex(q => q.id === quote.id);
  if (idx > -1) quotes[idx] = quote;
  else quotes.unshift(quote);
  await saveQuotes(quotes);
};

export const deleteQuote = async (id: string) => {
  const quotes = await getQuotes();
  await saveQuotes(quotes.filter(q => q.id !== id));
};

export const getNextQuoteNum = async (): Promise<string> => {
  const quotes = await getQuotes();
  if (!quotes.length) return 'NSE001';
  const nums = quotes.map(q => parseInt((q.quoteNum || 'NSE000').replace('NSE', '')) || 0);
  return 'NSE' + String(Math.max(...nums) + 1).padStart(3, '0');
};

export const DEFAULT_TERMS = `1. System installed within 15–30 days upon receipt of 70% advance.
2. Price valid for 7 days from quotation date.
3. Price includes 1st year maintenance.
4. GST: Panel/Inverter 5%, Services/BOS/Structure 18%, effective ~8.90% on EPC.
5. Net metering in customer scope unless specified.
6. Payment: 25% order confirmation · 45% before dispatch · 30% before installation.
7. Cancellation: No charge within 7 days. 15% charge after 7 days. No refund after dispatch.
8. Performance warranty: 90% for 10 Yrs, 80% for 15 Yrs (25 Yr manufacturer warranty).
9. Inverter warranty: 5–10 Years. AMC extra after 5 years.
10. All government permits handled by N Square Energies team.`;

export const getSettings = async (): Promise<Settings> => {
  const raw = await AsyncStorage.getItem(SETTINGS_KEY);
  const d = raw ? JSON.parse(raw) : {};
  return {
    coName: d.coName || 'N Square Energies',
    coAddr: d.coAddr || '',
    coPhone: d.coPhone || '8838098525',
    coEmail: d.coEmail || 'info@nsquareenergies.com',
    gst5: d.gst5 || 5,
    gst18: d.gst18 || 18,
    validity: d.validity || 7,
    sigName: d.sigName || '',
    sigDesig: d.sigDesig || 'Director',
    terms: d.terms || DEFAULT_TERMS,
  };
};

export const saveSettings = async (s: Settings) => {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
};
```

---

## ⚡ src/utils/gst.ts
```typescript
export function calcGST(base: number, gst5: number, gst18: number) {
  const part70 = base * 0.7;
  const part30 = base * 0.3;
  const g5 = part70 * (gst5 / 100);
  const g18 = part30 * (gst18 / 100);
  const gstTotal = g5 + g18;
  const grandTotal = base + gstTotal;
  const effectivePct = base > 0 ? ((gstTotal / base) * 100).toFixed(2) : '8.90';
  return { part70, part30, g5, g18, gstTotal, grandTotal, effectivePct };
}

export function fINR(n: number): string {
  return '₹' + n.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
```

---

## 📄 src/utils/pdfBuilder.ts
```typescript
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Quote, Settings } from './db';
import { fINR } from './gst';

export async function generateAndSharePDF(quote: Quote, settings: Settings) {
  const html = buildPDFHTML(quote, settings);
  const { uri } = await Print.printToFileAsync({ html, base64: false });
  await Sharing.shareAsync(uri, {
    mimeType: 'application/pdf',
    dialogTitle: `Quote ${quote.quoteNum}`,
  });
}

function buildPDFHTML(q: Quote, s: Settings): string {
  // Full PDF HTML same as web app version
  // (abbreviated here for readability — full version in web app)
  return `<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #111; }
    .header { display: flex; justify-content: space-between; border-bottom: 3px solid #1db954; padding-bottom: 12px; margin-bottom: 16px; }
    .company h1 { color: #0d8c3c; font-size: 20px; margin: 0; }
    .title-bar { background: #0a2e0a; color: white; padding: 12px 16px; border-radius: 6px; margin-bottom: 14px; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th { background: #0d8c3c; color: white; padding: 8px; text-align: left; }
    td { padding: 7px 8px; border-bottom: 1px solid #e8f5e8; }
    .grand { background: #1db954; color: white; font-weight: bold; font-size: 14px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="company">
      <h1>${s.coName}</h1>
      <p>${s.coAddr} | ${s.coPhone}</p>
    </div>
    <div style="text-align:right;">
      <strong>${q.quoteNum}</strong><br/>
      ${q.date}
    </div>
  </div>
  <div class="title-bar">
    <strong>SOLAR INSTALLATION QUOTATION · ${q.sysType} · ${q.kw} kWp</strong>
  </div>
  <p><strong>Customer:</strong> ${q.name} | ${q.phone}</p>
  <p><strong>Address:</strong> ${q.address}</p>
  <table>
    <tr><th>Description</th><th>Amount</th></tr>
    <tr><td>Project Cost (Before GST)</td><td>${fINR(q.baseCost)}</td></tr>
    <tr><td>GST on Equipment (70% @ 5%)</td><td>${fINR(q.g5)}</td></tr>
    <tr><td>GST on Services (30% @ 18%)</td><td>${fINR(q.g18)}</td></tr>
    <tr><td>Total GST</td><td>${fINR(q.gstTotal)}</td></tr>
    <tr class="grand"><td>GRAND TOTAL</td><td>${fINR(q.grandTotal)}</td></tr>
  </table>
  <p><em>${s.terms}</em></p>
</body>
</html>`;
}
```

---

## 📲 HOW TO INSTALL ON YOUR PHONE (Web PWA – No Compilation)

1. Open the **NSE_QUOTATION.html** file on your phone browser (Chrome)
2. Tap the **3-dot menu** → **"Add to Home Screen"**
3. App installs like a native app — works **100% offline**
4. All data saved locally on your device

---

## 📞 SUPPORT
N Square Energies · 8838098525
